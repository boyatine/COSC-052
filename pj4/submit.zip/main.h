#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include "list.h"
#include "nosuchobject.h"

using namespace std;

#endif