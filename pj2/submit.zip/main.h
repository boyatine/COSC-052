#ifndef MAIN_H
#define MAIN_H

#include <cstdlib>
#include <iostream>
#include "bikes.h"

using namespace std;

#endif // MAIN_H

