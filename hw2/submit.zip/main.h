#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <cstdlib>
#include <ctime>
#include "deck.h"
#include "hand.h"

using namespace std;

#endif
